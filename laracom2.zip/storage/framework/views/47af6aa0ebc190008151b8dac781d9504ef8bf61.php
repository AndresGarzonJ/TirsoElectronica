<label for="tag">Etiqueta </label>
<select name="tag" id="tag" class="form-control">
    <option value="Deshabilidado" <?php if($tag == "Deshabilidado"): ?> selected="selected" <?php endif; ?>>Deshabilitado</option>
    <option value="Nuevo" <?php if($tag == "Nuevo"): ?> selected="selected" <?php endif; ?>>Nuevo</option>
    <option value="En Oferta" <?php if($tag == "En Oferta"): ?> selected="selected" <?php endif; ?>>En Oferta</option>
    <option value="Destacado" <?php if($tag == "Destacado"): ?> selected="selected" <?php endif; ?>>Destacado</option>
</select>