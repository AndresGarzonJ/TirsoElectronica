 
 
<?php $__env->startSection('og'); ?>  
    <meta property="og:type" content="blog"/>
    <meta property="og:title" content="<?php echo e($blog->name_blog); ?>"/>
    <meta property="og:description" content="<?php echo e(strip_tags($blog->description)); ?>"/>
    <?php if(!is_null($blog->cover)): ?>
        <meta property="og:image" content="<?php echo e(asset("storage/$blog->cover")); ?>"/>
    <?php endif; ?>
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?>
    <div class="inner-page-banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="breadcrumb-area">
                        <h1>Blog Details</h1>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a> /</li>
                            <li><a href="#">Category</a> /</li>
                            <li>Blog /</li>
                            <li>Details</li>
                        </ul>
                    </div>
                </div> 
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.front.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>