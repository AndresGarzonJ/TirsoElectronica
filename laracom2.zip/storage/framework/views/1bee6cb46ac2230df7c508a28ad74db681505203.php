<?php $__env->startSection('css'); ?>
   
<?php $__env->stopSection(); ?>


<?php $__env->startSection('og'); ?>
    <!--
        El Open Graph Protocol es un método simple que nos permite incluir meta información en nuestra página web y así convertirla en un objeto Social Graph, una vez siendo un objeto puede interactuar con otros objetos Social Graph como el share de Google+ o el like de Facebook de modo correcto.
    -->
    <meta property="og:type" content="home"/>
    <meta property="og:title" content="<?php echo e(config('app.name')); ?>"/>
    <meta property="og:description" content="<?php echo e(config('app.name')); ?>"/>
<?php $__env->stopSection(); ?>
 


<?php $__env->startSection('content'); ?>
    <div class="inner-page-banner-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="breadcrumb-area">
                        <h1>Tutoriales/Blogs</h1>
                        <ul>
                            <li><a href="/">Home</a> /</li>
                            <li>Blog</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Inner Page Banner Area End Here -->
    <!-- Blog Page Area Start Here -->
    <div class="blog-page-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                    <?php echo $__env->make('layouts.front.blog-side-right', ['blogs' => $recentBlogs], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                    <div class="row">
                        <?php if(!is_null($blogs)): ?> 
                            <?php echo $__env->make('front.blogs.blog-list', ['blogs' => $blogs, 'form_list' => "grid"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            
                        <?php endif; ?>
                    </div>                    
                </div>                
            </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>