<?php if(!empty($blogs) && !collect($blogs)->isEmpty()): ?>

    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

        <?php 
            $months = [
                '-01-' => '-Enero-', 
                '-02-' => '-Febrero-', 
                '-03-' => '-Marzo-',
                '-04-' => '-Abril-', 
                '-05-' => '-Mayo-',
                '-06-' => '-Junio-',
                '-07-' => '-Julio-',
                '-08-' => '-Agosto-',
                '-09-' => '-Septiembre-',
                '-10-' => '-Octubre-',
                '-11-' => '-Noviembre-',
                '-12-' => '-Diciembre-'
            ];  
            
            $date_split = substr($blog->updated_at, 0, -9);
            $date = str_replace(array_keys($months), $months, $date_split);
            $date_array = explode("-", $date);
                
        ?>
        
        <div
        <?php if($form_list == "grid"): ?>         
            class="col-lg-6 col-md-6 col-sm-6 col-xs-6"
        <?php endif; ?>
        > 

            
            <?php if($form_list == "grid"): ?>         
                <div class="blog-page-box">
                        <!-- ---------- La siguiente vista es la pag principal de Blogs ------------------ -->
                        <div class="blog-img-holder">
                            <?php if(isset($blog->cover)): ?>
                                <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>">
                                    <img 
                                    src="<?php echo e(asset("storage/$blog->cover")); ?>"
                                    alt="<?php echo e($blog->name_blog); ?>"
                                    height="273"
                                    width="422"
                                    class="img-responsive">
                                </a>

                            <?php else: ?>
                                <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>">
                                    <img 
                                    src="https://placehold.it/263x330"
                                    alt="<?php echo e($blog->name_blog); ?>"
                                    height="273"
                                    width="422"
                                    class="img-responsive">
                                </a>
                            <?php endif; ?>  
                        </div>
                        <div class="blog-content-holder">
                            <span><?php echo e($date_array[1]); ?> <?php echo e($date_array[2]); ?>, <?php echo e($date_array[0]); ?></span>
                            <h3><a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>" ><?php echo e($blog->name_blog); ?></a></h3>
                            <ul>
                                <li><span>by</span> <?php echo e($blog->name_creator); ?></li>
                                <li>Comments (05)</li>
                            </ul>
                            <?php echo $blog->description_short; ?>

                        </div>               

            <?php endif; ?>
            <?php if($form_list == "listCarousel"): ?> 
                
                <div class="blog-box">
                        <!-- ---------- La siguiente vista es para el index "Carrusel" ----------------------- -->
                        <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>"><span><i class="fa fa-chevron-right" aria-hidden="true"></i></span></a>
                        <div class="blog-img-holder">
                            <div class="post-date">
                                <span><?php echo e($date_array[1]); ?> <?php echo e($date_array[2]); ?></span>
                            </div>

                            <?php if(isset($blog->cover)): ?>
                                <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>">
                                    <img 
                                    src="<?php echo e(asset("storage/$blog->cover")); ?>"
                                    alt="<?php echo e($blog->name_blog); ?>"
                                    height="219"
                                    width="373"                                    
                                    class="img-bordered img-responsive">
                                </a>

                            <?php else: ?>
                                <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>">
                                    <img 
                                    src="https://placehold.it/263x330"
                                    alt="<?php echo e($blog->name_blog); ?>"
                                    height="219"
                                    width="373"                                    
                                    class="img-bordered img-responsive">
                                </a>
                            <?php endif; ?>  
                            
                        </div>
                        <div class="blog-content-holder">
                            <h3><a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>" ><?php echo e($blog->name_blog); ?></a></h3>
                            <ul class="solid-underline">
                                <li><span>by</span> <?php echo e($blog->name_creator); ?></li>
                                <li>Comments (03)</li>
                            </ul>
                            <?php echo $blog->description_short; ?>

                        </div>
            <?php endif; ?>

            <?php if($form_list == "column"): ?> 
                <div class="media">
                    <?php if(isset($blog->cover)): ?>
                        <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>" class="pull-left">
                            <img 
                            src="<?php echo e(asset("storage/$blog->cover")); ?>"
                            alt="<?php echo e($blog->name_blog); ?>"
                            height="107"
                            width="107"
                            class="img-responsive">
                        </a>

                    <?php else: ?>
                        <a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>" class="pull-left">
                            <img 
                            src="https://placehold.it/263x330"
                            alt="<?php echo e($blog->name_blog); ?>"
                            height="107"
                            width="107"
                            class="img-responsive">
                        </a>
                    <?php endif; ?>



                    <div class="media-body">
                        <h3 class="media-heading"><a href="<?php echo e(route('front.get.blog', str_slug($blog->slug))); ?>"><?php echo e($blog->name_blog); ?></a></h3>
                        <!-- dia mes, anio -->
                        <p><?php echo e($date_array[1]); ?> <?php echo e($date_array[2]); ?>, <?php echo e($date_array[0]); ?></p>
                    </div>                 
            <?php endif; ?>

            </div>            
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($blogs instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="mypagination"><?php echo e($blogs->links()); ?></div>
            </div>
        </div>
        
        <!-- 
        <div class="row">
            <div class="col-md-12">
                <div class="pull-left">{ $blogs->links() }}</div>
            </div>
        </div>
        -->
    <?php endif; ?>
<?php else: ?>
    <p class="alert alert-warning">No blogs yet.</p>
<?php endif; ?>