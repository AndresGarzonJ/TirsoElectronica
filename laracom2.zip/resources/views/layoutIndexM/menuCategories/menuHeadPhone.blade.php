Head Phone<span><i class="flaticon-next"></i></span></a>
<ul class="dropdown-menu">
    <li><a href={{asset("#")}}>Head Phone Sub Title 1</a></li>
    <li><a href={{asset("#")}}>Head Phone Sub Title 2</a></li>
    <li><a href={{asset("#")}}>Head Phone Sub Title 3</a></li>
    <li><a href={{asset("#")}}>Head Phone Sub Title 4</a></li>
    <li><a href={{asset("#")}}>Head Phone Sub Title 5</a></li>
</ul>