<?php

namespace App\Shop\Customers\Exceptions;

class UpdateCustomerInvalidArgumentException extends \InvalidArgumentException
{
}
