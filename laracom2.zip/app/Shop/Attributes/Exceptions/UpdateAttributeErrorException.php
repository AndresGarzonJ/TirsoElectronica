<?php

namespace App\Shop\Attributes\Exceptions;

class UpdateAttributeErrorException extends \Exception
{
}