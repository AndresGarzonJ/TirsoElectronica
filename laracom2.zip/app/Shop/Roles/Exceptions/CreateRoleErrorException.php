<?php

namespace App\Shop\Roles\Exceptions;

class CreateRoleErrorException extends \Exception
{

}