<?php

namespace App\Shop\OrderDetails\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class OrderDetailInvalidArgumentException extends InvalidArgumentException
{
}
