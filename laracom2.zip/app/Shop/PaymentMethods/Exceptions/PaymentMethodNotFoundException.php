<?php

namespace App\Shop\PaymentMethods\Exceptions;

class PaymentMethodNotFoundException extends \Exception
{
}
