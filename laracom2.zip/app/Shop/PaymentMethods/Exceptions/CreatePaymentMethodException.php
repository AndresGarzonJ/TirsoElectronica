<?php

namespace App\Shop\PaymentMethods\Exceptions;

class CreatePaymentMethodException extends \Exception
{
}
