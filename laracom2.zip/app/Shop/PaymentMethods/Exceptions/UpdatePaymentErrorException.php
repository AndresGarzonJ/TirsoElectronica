<?php

namespace App\Shop\PaymentMethods\Exceptions;

class UpdatePaymentErrorException extends \Exception
{
}
