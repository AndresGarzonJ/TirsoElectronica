<?php

namespace App\Shop\Contacts\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class ContactInvalidArgumentException extends InvalidArgumentException
{
}
