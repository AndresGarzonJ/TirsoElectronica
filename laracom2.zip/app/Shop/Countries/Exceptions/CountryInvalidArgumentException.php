<?php

namespace App\Shop\Countries\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class CountryInvalidArgumentException extends InvalidArgumentException
{
}
