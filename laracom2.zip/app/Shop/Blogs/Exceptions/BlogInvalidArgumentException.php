<?php

namespace App\Shop\Blogs\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class BlogInvalidArgumentException extends InvalidArgumentException
{
}
