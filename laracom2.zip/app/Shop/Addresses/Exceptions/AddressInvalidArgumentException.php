<?php

namespace App\Shop\Addresses\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class AddressInvalidArgumentException extends InvalidArgumentException
{
}
