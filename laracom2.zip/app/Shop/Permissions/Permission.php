<?php

namespace App\Shop\Permissions;

use Laratrust\Models\LaratrustPermission;

class Permission extends LaratrustPermission
{

}